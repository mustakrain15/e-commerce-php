now you first upan create data table name finalproject
import sql file 
change conncetion port no localhost only
adminpanle user name and password is admin admin
